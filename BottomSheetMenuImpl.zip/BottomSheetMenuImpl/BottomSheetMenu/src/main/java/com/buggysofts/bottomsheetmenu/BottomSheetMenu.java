package com.buggysofts.bottomsheetmenu;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.view.menu.MenuBuilder;
import android.view.Menu;
import android.view.View;

public class BottomSheetMenu {
    // host activity
    private Activity activity;

    // menu to be shown
    private Menu currentMenu;

    // header and footer views - not visible if null
    private View headerView;
    private View footerView;

    public BottomSheetMenu(@NonNull Activity activity, int menuRes) {
        this.activity = activity;
        this.currentMenu = menu;
    }
    public BottomSheetMenu(@NonNull Activity activity, @NonNull Menu menu) {
        this.activity = activity;
        this.currentMenu = menu;
    }

    private Menu getMenuFromMenuRes(Activity activity, int menuRes){
        MenuBuilder builder = new MenuBuilder(activity)
    }
}
